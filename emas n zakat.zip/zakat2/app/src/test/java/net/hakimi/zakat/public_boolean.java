package net.hakimi.zakat;

public class public_boolean {
}
